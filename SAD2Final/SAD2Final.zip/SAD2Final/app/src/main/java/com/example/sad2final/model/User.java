package com.example.sad2final.model;

public class User {

    public String name, email, contact, password, address;

    public User() {}

    public User (String name, String email, String contact,  String password, String address) {
        this.name = name;
        this.email= email;
        this.contact = contact;
        this.password = password;
        this.address = address;
    }
}
